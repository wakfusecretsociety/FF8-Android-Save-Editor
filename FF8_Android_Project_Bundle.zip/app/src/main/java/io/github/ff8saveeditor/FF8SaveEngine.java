package io.github.ff8saveeditor;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Arrays;

public final class FF8SaveEngine {
    public static final int MOBILE_FILE_SIZE = 10240;
    public static final int DECOMPRESSED_SIZE = 8192;
    private static final int MOBILE_MARKER_OFFSET = 6328;

    private static final int MAIN_START = 464;
    private static final int MAIN_END = 5408;
    private static final int CHECKSUM_HEADER = 384;
    private static final int CHECKSUM_FOOTER = 5408;

    private static final int[] GIL_OFFSETS = {396, 3212, 3880};

    private static final int GF_BASE = 464;
    private static final int GF_SIZE = 68;
    private static final int GF_COUNT = 16;
    private static final int GF_EXISTS_OFFSET = 17;

    private static final int CHARACTERS_BASE = 1552;
    private static final int CHARACTER_SIZE = 152;
    private static final int CHARACTER_COUNT = 8;
    private static final int MAGIC_OFFSET = 16;
    private static final int MAGIC_SLOTS = 32;

    private static final int INVENTORY_BASE = 3268;
    private static final int INVENTORY_SLOTS = 198;

    private static final int TTCARDS_BASE = 5216;
    private static final int COMMON_CARD_COUNT = 77;
    private static final int RARE_CARD_COUNT = 33;

    private static final int SEED_EXP_OFFSET = 3824;
    private static final int SEED_MAX_EXP = 3110;

    private static final int FIELD_BASE = 4064;
    private static final int TT_RULES_OFFSET = FIELD_BASE + 16;
    private static final int TT_REGION_COUNT = 8;
    private static final int TT_OPEN_ONLY = 0x01;

    private final byte[] originalRaw;
    private final byte[] data;

    private static final int[][] OPTIMIZED_MAGICS = {
        {3, 100}, {6, 100}, {9, 100}, {10, 100},
        {13, 100}, {14, 100}, {15, 100}, {16, 100},
        {17, 100}, {18, 100}, {19, 100}, {23, 100},
        {25, 100}, {26, 100}, {27, 100}, {28, 100},
        {29, 100}, {30, 100}, {31, 100}, {32, 100},
        {33, 100}, {34, 100}, {35, 100}, {36, 100},
        {37, 100}, {38, 100}, {39, 100}, {40, 100},
        {41, 100}, {43, 100}, {45, 100}, {49, 100}
    };

    private static final int[] ULTIMATE_ITEM_IDS = buildUltimateItemIds();

    public FF8SaveEngine(byte[] raw) {
        if (raw == null || raw.length != MOBILE_FILE_SIZE) {
            throw new IllegalArgumentException("Le fichier doit faire exactement 10 240 octets.");
        }
        this.originalRaw = Arrays.copyOf(raw, raw.length);
        this.data = decompressMobile(raw);
    }

    public Summary summary() {
        int gils = readIntLE(data, 3212);

        int gf = 0;
        for (int i = 0; i < GF_COUNT; i++) {
            if ((data[GF_BASE + i * GF_SIZE + GF_EXISTS_OFFSET] & 0xFF) != 0) gf++;
        }

        int items = 0;
        for (int i = 0; i < INVENTORY_SLOTS; i++) {
            if ((data[INVENTORY_BASE + i * 2] & 0xFF) != 0) items++;
        }

        int commonCards = 0;
        for (int i = 0; i < COMMON_CARD_COUNT; i++) {
            if ((data[TTCARDS_BASE + i] & 0x7F) != 0) commonCards++;
        }

        int rareBase = TTCARDS_BASE + COMMON_CARD_COUNT;
        int rareCards = 0;
        for (int i = 0; i < RARE_CARD_COUNT; i++) {
            if ((data[rareBase + i] & 0xFF) == 240) rareCards++;
        }

        int seedExp = readShortLE(data, SEED_EXP_OFFSET);

        int openRegions = 0;
        for (int i = 0; i < TT_REGION_COUNT; i++) {
            if ((data[TT_RULES_OFFSET + i] & 0xFF) == TT_OPEN_ONLY) openRegions++;
        }

        return new Summary(gils, gf, items, commonCards, rareCards, seedExp, openRegions);
    }

    public void setGils(int amount) {
        int safe = Math.max(0, amount);
        for (int offset : GIL_OFFSETS) writeIntLE(data, offset, safe);
    }

    public void unlockAllGf() {
        for (int i = 0; i < GF_COUNT; i++) {
            data[GF_BASE + i * GF_SIZE + GF_EXISTS_OFFSET] = 1;
        }
    }

    public void setOptimizedMagic() {
        for (int character = 0; character < CHARACTER_COUNT; character++) {
            int base = CHARACTERS_BASE + character * CHARACTER_SIZE + MAGIC_OFFSET;
            Arrays.fill(data, base, base + MAGIC_SLOTS * 2, (byte) 0);
            for (int slot = 0; slot < OPTIMIZED_MAGICS.length; slot++) {
                int id = OPTIMIZED_MAGICS[slot][0];
                int quantity = OPTIMIZED_MAGICS[slot][1];
                writeShortLE(data, base + slot * 2, id | (quantity << 8));
            }
        }
    }

    public void setUltimateInventory() {
        Arrays.fill(data, INVENTORY_BASE, INVENTORY_BASE + INVENTORY_SLOTS * 2, (byte) 0);
        int count = Math.min(ULTIMATE_ITEM_IDS.length, INVENTORY_SLOTS);
        for (int slot = 0; slot < count; slot++) {
            data[INVENTORY_BASE + slot * 2] = (byte) ULTIMATE_ITEM_IDS[slot];
            data[INVENTORY_BASE + slot * 2 + 1] = 99;
        }
    }

    public void restockExistingInventory() {
        for (int slot = 0; slot < INVENTORY_SLOTS; slot++) {
            int id = data[INVENTORY_BASE + slot * 2] & 0xFF;
            if (id != 0) data[INVENTORY_BASE + slot * 2 + 1] = 99;
        }
    }

    public void unlockAllCards() {
        for (int i = 0; i < COMMON_CARD_COUNT; i++) {
            data[TTCARDS_BASE + i] = (byte) (0x80 | 99);
        }

        int rareLocations = TTCARDS_BASE + COMMON_CARD_COUNT;
        for (int i = 0; i < RARE_CARD_COUNT; i++) {
            data[rareLocations + i] = (byte) 240;
        }

        int rareMask = rareLocations + RARE_CARD_COUNT;
        byte[] mask = {(byte) 0xFF, (byte) 0xFF, (byte) 0xFF, (byte) 0xFF, 0x01};
        System.arraycopy(mask, 0, data, rareMask, mask.length);
    }

    public void setSeedRankMax() {
        writeShortLE(data, SEED_EXP_OFFSET, SEED_MAX_EXP);
    }

    public void setTripleTriadOpenEverywhere() {
        Arrays.fill(data, TT_RULES_OFFSET, TT_RULES_OFFSET + TT_REGION_COUNT, (byte) TT_OPEN_ONLY);
        data[FIELD_BASE + 32] = (byte) TT_OPEN_ONLY;
        data[FIELD_BASE + 33] = 0;
    }

    public void applyUltimateProfile() {
        setGils(1_000_000);
        unlockAllGf();
        setOptimizedMagic();
        setUltimateInventory();
        unlockAllCards();
        setSeedRankMax();
        setTripleTriadOpenEverywhere();
    }

    public byte[] build() {
        int checksum = checksum(Arrays.copyOfRange(data, MAIN_START, MAIN_END));
        writeShortLE(data, CHECKSUM_HEADER, checksum);
        writeShortLE(data, CHECKSUM_FOOTER, checksum);

        byte[] compressed = literalRecompress(data);
        byte[] result = new byte[MOBILE_FILE_SIZE];
        writeIntLE(result, 0, compressed.length);
        System.arraycopy(compressed, 0, result, 4, compressed.length);
        result[MOBILE_MARKER_OFFSET] = originalRaw[MOBILE_MARKER_OFFSET];
        return result;
    }

    private static byte[] decompressMobile(byte[] raw) {
        int compressedSize = readIntLE(raw, 0);
        if (compressedSize <= 0 || compressedSize > raw.length - 4) {
            throw new IllegalArgumentException("En-tête de compression invalide.");
        }

        byte[] input = Arrays.copyOfRange(raw, 4, 4 + compressedSize);
        byte[] ring = new byte[4113];
        int ringPos = 4078;
        byte[] output = new byte[DECOMPRESSED_SIZE];
        int outPos = 0;
        int index = 0;
        int flags = 0;

        while (index < input.length && outPos < DECOMPRESSED_SIZE) {
            flags >>= 1;
            if ((flags & 0x100) == 0) {
                flags = (input[index] & 0xFF) | 0xFF00;
                index++;
            }

            if ((flags & 1) != 0) {
                int value = input[index++] & 0xFF;
                output[outPos++] = (byte) value;
                ring[ringPos] = (byte) value;
                ringPos = (ringPos + 1) & 4095;
            } else {
                if (index + 1 >= input.length) break;
                int address = input[index++] & 0xFF;
                int lengthCode = input[index++] & 0xFF;
                address |= (lengthCode & 0xF0) << 4;
                int end = address + (lengthCode & 0x0F) + 2;

                for (int position = address; position <= end && outPos < DECOMPRESSED_SIZE; position++) {
                    byte value = ring[position & 4095];
                    output[outPos++] = value;
                    ring[ringPos] = value;
                    ringPos = (ringPos + 1) & 4095;
                }
            }
        }

        if (outPos != DECOMPRESSED_SIZE || output[0] != 'S' || output[1] != 'C') {
            throw new IllegalArgumentException("Sauvegarde FFVIII Android non reconnue.");
        }
        return output;
    }

    private static byte[] literalRecompress(byte[] input) {
        byte[] encoded = new byte[9216];
        int out = 0;
        for (int start = 0; start < input.length; start += 8) {
            int length = Math.min(8, input.length - start);
            encoded[out++] = (byte) ((1 << length) - 1);
            System.arraycopy(input, start, encoded, out, length);
            out += length;
        }
        return Arrays.copyOf(encoded, out);
    }

    private static int checksum(byte[] mainData) {
        int crc = 0xFFFF;
        for (byte value : mainData) {
            int index = ((crc >> 8) ^ (value & 0xFF)) & 0xFF;
            crc = crcTableValue(index) ^ ((crc << 8) & 0xFFFF);
        }
        return (~crc) & 0xFFFF;
    }

    // CRC-16/CCITT table value generated at runtime to avoid embedding 256 constants.
    private static int crcTableValue(int index) {
        int value = index << 8;
        for (int bit = 0; bit < 8; bit++) {
            value = ((value & 0x8000) != 0)
                ? ((value << 1) ^ 0x1021)
                : (value << 1);
            value &= 0xFFFF;
        }
        return value;
    }

    private static int[] buildUltimateItemIds() {
        int[] temp = new int[198];
        int count = 0;

        int[] fixed = {5,6,7,8,9,10,16,17,19,21,31,33,35,39,40,41};
        for (int value : fixed) temp[count++] = value;
        for (int value = 49; value <= 65; value++) temp[count++] = value;
        for (int value = 66; value <= 126; value++) temp[count++] = value;
        for (int value = 127; value <= 141; value++) temp[count++] = value;
        for (int value = 142; value <= 162; value++) temp[count++] = value;
        for (int value = 171; value <= 178; value++) temp[count++] = value;
        for (int value = 179; value <= 200; value++) temp[count++] = value;

        return Arrays.copyOf(temp, count);
    }

    private static int readIntLE(byte[] bytes, int offset) {
        return ByteBuffer.wrap(bytes, offset, 4).order(ByteOrder.LITTLE_ENDIAN).getInt();
    }

    private static int readShortLE(byte[] bytes, int offset) {
        return ByteBuffer.wrap(bytes, offset, 2).order(ByteOrder.LITTLE_ENDIAN).getShort() & 0xFFFF;
    }

    private static void writeIntLE(byte[] bytes, int offset, int value) {
        ByteBuffer.wrap(bytes, offset, 4).order(ByteOrder.LITTLE_ENDIAN).putInt(value);
    }

    private static void writeShortLE(byte[] bytes, int offset, int value) {
        ByteBuffer.wrap(bytes, offset, 2).order(ByteOrder.LITTLE_ENDIAN).putShort((short) value);
    }

    public record Summary(
        int gils,
        int availableGf,
        int populatedItems,
        int commonCards,
        int rareCards,
        int seedExp,
        int openRegions
    ) {}
}
