package io.github.ff8saveeditor;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public final class MainActivity extends Activity {
    private static final int REQUEST_OPEN = 1001;
    private static final int REQUEST_SAVE = 1002;

    private byte[] sourceBytes;
    private String sourceName = "slot1_save03.ff8";

    private TextView fileText;
    private TextView analysisText;
    private Button saveButton;

    private CheckBox ultimate;
    private CheckBox gils;
    private CheckBox allGf;
    private CheckBox magic;
    private CheckBox inventory;
    private CheckBox restock;
    private CheckBox cards;
    private CheckBox seed;
    private CheckBox ttOpen;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(buildUi());
    }

    private View buildUi() {
        int pad = dp(16);

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("FF8 Android Save Editor");
        title.setTextSize(24);
        title.setTextColor(Color.BLACK);
        title.setPadding(0, 0, 0, dp(4));
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Final Fantasy VIII Remastered — Android");
        subtitle.setTextSize(15);
        subtitle.setPadding(0, 0, 0, dp(16));
        root.addView(subtitle);

        Button openButton = new Button(this);
        openButton.setText("1. Ouvrir une sauvegarde .ff8");
        openButton.setOnClickListener(v -> openDocument());
        root.addView(openButton);

        fileText = new TextView(this);
        fileText.setText("Aucun fichier chargé");
        fileText.setPadding(0, dp(8), 0, dp(12));
        root.addView(fileText);

        analysisText = new TextView(this);
        analysisText.setText("L’analyse apparaîtra ici.");
        analysisText.setTextSize(15);
        analysisText.setBackgroundColor(0xFFF2F2F2);
        analysisText.setPadding(pad, pad, pad, pad);
        root.addView(analysisText);

        TextView optionsTitle = new TextView(this);
        optionsTitle.setText("Modifications");
        optionsTitle.setTextSize(20);
        optionsTitle.setTextColor(Color.BLACK);
        optionsTitle.setPadding(0, dp(18), 0, dp(6));
        root.addView(optionsTitle);

        ultimate = option("Profil Ultimate complet");
        gils = option("1 000 000 Gils");
        allGf = option("Activer les 16 G-Forces");
        magic = option("Magies optimisées ×100");
        inventory = option("Inventaire Ultimate ×99");
        restock = option("Réapprovisionner les objets présents à 99");
        cards = option("Toutes les cartes Triple Triad");
        seed = option("Rang SeeD A");
        ttOpen = option("Triple Triad : Open partout");

        root.addView(ultimate);
        root.addView(gils);
        root.addView(allGf);
        root.addView(magic);
        root.addView(inventory);
        root.addView(restock);
        root.addView(cards);
        root.addView(seed);
        root.addView(ttOpen);

        ultimate.setOnCheckedChangeListener((button, checked) -> {
            if (checked) {
                gils.setChecked(true);
                allGf.setChecked(true);
                magic.setChecked(true);
                inventory.setChecked(true);
                restock.setChecked(false);
                cards.setChecked(true);
                seed.setChecked(true);
                ttOpen.setChecked(true);
            }
        });

        saveButton = new Button(this);
        saveButton.setText("2. Créer la sauvegarde modifiée");
        saveButton.setEnabled(false);
        saveButton.setOnClickListener(v -> createDocument());
        LinearLayout.LayoutParams saveParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        saveParams.topMargin = dp(18);
        root.addView(saveButton, saveParams);

        TextView help = new TextView(this);
        help.setText(
            "Le fichier original n’est jamais modifié. " +
            "L’application exporte un nouveau fichier que tu peux recopier dans le dossier du jeu."
        );
        help.setPadding(0, dp(12), 0, dp(24));
        root.addView(help);

        return scroll;
    }

    private CheckBox option(String label) {
        CheckBox box = new CheckBox(this);
        box.setText(label);
        box.setTextSize(16);
        box.setPadding(0, dp(3), 0, dp(3));
        return box;
    }

    private void openDocument() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        startActivityForResult(intent, REQUEST_OPEN);
    }

    private void createDocument() {
        if (sourceBytes == null) return;

        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/octet-stream");
        intent.putExtra(Intent.EXTRA_TITLE, editedName(sourceName));
        startActivityForResult(intent, REQUEST_SAVE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent result) {
        super.onActivityResult(requestCode, resultCode, result);
        if (resultCode != RESULT_OK || result == null || result.getData() == null) return;

        Uri uri = result.getData();
        try {
            if (requestCode == REQUEST_OPEN) {
                sourceBytes = readAll(uri);
                sourceName = queryName(uri);
                FF8SaveEngine engine = new FF8SaveEngine(sourceBytes);
                showSummary(engine.summary());
                fileText.setText(sourceName);
                saveButton.setEnabled(true);
                Toast.makeText(this, "Sauvegarde chargée", Toast.LENGTH_SHORT).show();
            } else if (requestCode == REQUEST_SAVE) {
                FF8SaveEngine engine = new FF8SaveEngine(sourceBytes);
                applyOptions(engine);
                byte[] output = engine.build();
                try (OutputStream stream = getContentResolver().openOutputStream(uri, "w")) {
                    if (stream == null) throw new IllegalStateException("Impossible d’ouvrir le fichier de sortie.");
                    stream.write(output);
                }
                Toast.makeText(this, "Sauvegarde créée avec succès", Toast.LENGTH_LONG).show();
            }
        } catch (Exception error) {
            Toast.makeText(this, error.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void applyOptions(FF8SaveEngine engine) {
        if (ultimate.isChecked()) {
            engine.applyUltimateProfile();
            return;
        }
        if (gils.isChecked()) engine.setGils(1_000_000);
        if (allGf.isChecked()) engine.unlockAllGf();
        if (magic.isChecked()) engine.setOptimizedMagic();
        if (inventory.isChecked()) engine.setUltimateInventory();
        if (restock.isChecked()) engine.restockExistingInventory();
        if (cards.isChecked()) engine.unlockAllCards();
        if (seed.isChecked()) engine.setSeedRankMax();
        if (ttOpen.isChecked()) engine.setTripleTriadOpenEverywhere();
    }

    private void showSummary(FF8SaveEngine.Summary s) {
        analysisText.setText(
            "Gils : " + s.gils() + "\n" +
            "G-Forces : " + s.availableGf() + "/16\n" +
            "Objets présents : " + s.populatedItems() + "/198\n" +
            "Cartes communes : " + s.commonCards() + "/77\n" +
            "Cartes rares : " + s.rareCards() + "/33\n" +
            "Expérience SeeD : " + s.seedExp() + "\n" +
            "Régions en Open : " + s.openRegions() + "/8"
        );
    }

    private byte[] readAll(Uri uri) throws Exception {
        try (InputStream input = getContentResolver().openInputStream(uri);
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            if (input == null) throw new IllegalStateException("Impossible d’ouvrir ce fichier.");
            byte[] buffer = new byte[8192];
            int read;
            while ((read = input.read(buffer)) != -1) output.write(buffer, 0, read);
            return output.toByteArray();
        }
    }

    private String queryName(Uri uri) {
        try (android.database.Cursor cursor = getContentResolver().query(
            uri, null, null, null, null
        )) {
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) return cursor.getString(index);
            }
        }
        return "slot1_save03.ff8";
    }

    private static String editedName(String name) {
        int dot = name.lastIndexOf('.');
        if (dot > 0) return name.substring(0, dot) + "_edited.ff8";
        return name + "_edited.ff8";
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
