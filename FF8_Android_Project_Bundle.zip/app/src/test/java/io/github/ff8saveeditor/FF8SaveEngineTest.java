package io.github.ff8saveeditor;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class FF8SaveEngineTest {
    @Test
    public void placeholderBuildTest() {
        assertEquals(10240, FF8SaveEngine.MOBILE_FILE_SIZE);
        assertEquals(8192, FF8SaveEngine.DECOMPRESSED_SIZE);
    }
}
